<?php
$lang['quotation_website_quotation'] = "Сайт Цитата";

$lang['quotation_question_1'] = "Какой сайт вы ищете?";
$lang['quotation_question_1_aw_1'] = "целевых страниц";
$lang['quotation_question_1_aw_2'] = "Сайт компании";
$lang['quotation_question_1_aw_3'] = "Интернет-магазин";
$lang['quotation_question_1_aw_4'] = "Частное Главная";
$lang['quotation_question_1_aw_5'] = "Другие";

$lang['quotation_question_2'] = "Сколько страниц?";
$lang['quotation_question_2_aw_1'] = "1 - 5 страниц";
$lang['quotation_question_2_aw_2'] = "5 - 10 страниц";
$lang['quotation_question_2_aw_3'] = "10 - 30 страниц";
$lang['quotation_question_2_aw_4'] = "более 30 страниц";

$lang['quotation_question_3'] = "Хотите ли вы использовать систему управления контентом (CMS)?";
$lang['quotation_question_3_aw_1'] = "Да";
$lang['quotation_question_3_aw_2'] = "Нет";

$lang['quotation_question_4'] = "Есть ли пример сайт вам нравится?";

$lang['quotation_question_5'] = "Дайте нам немного информации о вашей, что вы делаете и что вы ожидаете ...";


$lang['quotation_question_6'] = "Каков ваш примерный бюджет сайта?";
$lang['quotation_question_6_aw_1'] = "менее 1000";
$lang['quotation_question_6_aw_2'] = "1000 2000";
$lang['quotation_question_6_aw_3'] = "2000 5000";
$lang['quotation_question_6_aw_4'] = "Более 5000";

$lang['quotation_question_7'] = "Название предприятия";
$lang['quotation_question_8'] = "Полное имя";
$lang['quotation_question_9'] = "Отправить";
$lang['quotation_question_10'] = "Телефон";
$lang['quotation_question_11'] = "улица";
$lang['quotation_question_12'] = "Город";
$lang['quotation_question_13'] = "Индекс";
$lang['quotation_question_14'] = "Страна";
$lang['quotation_question_15'] = "Дополнительные комментарии";

$lang['quotation_save'] = "Отправить Запрос коммерческого предложения";
$lang['quotation_create_error'] = "Что-то пошло не так!";
$lang['quotation_create_success'] = "Спасибо за requestion уникальные цитаты Мы проверим ваш запрос и свяжемся с Вами как можно скорее.!";
