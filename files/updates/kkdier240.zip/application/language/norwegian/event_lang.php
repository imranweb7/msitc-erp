<?php
$lang['event_invoice_overdue'] = 'Faktura {invoice_number} har <span class="label label-important">forfalt</span>';
$lang['event_project_overdue'] = 'Prosjekt {project_number} <span class="label label-important">deadline møtt</span>';
$lang['event_subscription_new_invoice'] = '<span class="label label-warning">Ny faktura</span> trengs til abonnement {subscription_number}';

