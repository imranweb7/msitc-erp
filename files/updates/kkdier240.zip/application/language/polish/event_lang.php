<?php
$lang['event_invoice_overdue'] = 'Płatność faktury {invoice_number} jest <span class="label label-important">po terminie</span> ';
$lang['event_project_overdue'] = 'Termin dla projektu {project_number} <span class="label label-important">został przekroczony</span>';
$lang['event_subscription_new_invoice'] = '<span class="label label-warning">Nowa faktura</span> dla subskrypcji {subscription_number}';

